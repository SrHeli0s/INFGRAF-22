Compilación:

	$> make

Ejecución:

	$> ./a.out